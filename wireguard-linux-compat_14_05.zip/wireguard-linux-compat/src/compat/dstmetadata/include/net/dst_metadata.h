#ifndef skb_valid_dst
#define skb_valid_dst(skb) (!!skb_dst(skb))
#endif
