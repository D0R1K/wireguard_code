/* SPDX-License-Identifier: GPL-2.0 OR MIT */
/*
 * Copyright (C) 2015-2019 Jason A. Donenfeld <Jason@zx2c4.com>. All Rights Reserved.
 */

#ifndef _ZINC_CHACHA20POLY1305_H
#define _ZINC_CHACHA20POLY1305_H

#include <linux/simd.h>
#include <linux/types.h>

struct scatterlist;

enum chacha20poly1305_lengths {
	XCHACHA20POLY1305_NONCE_SIZE = 24,
	CHACHA20POLY1305_KEY_SIZE = 32,
	CHACHA20POLY1305_AUTHTAG_SIZE = 16
};

void chacha20poly1305_encrypt(u8 *dst, const u8 *src, const size_t src_len,
			      const u8 *ad, const size_t ad_len,
			      const u64 nonce,
			      const u8 key[CHACHA20POLY1305_KEY_SIZE]);

bool __must_check chacha20poly1305_encrypt_sg_inplace(
	struct scatterlist *src, const size_t src_len, const u8 *ad,
	const size_t ad_len, const u64 nonce,
	const u8 key[CHACHA20POLY1305_KEY_SIZE], simd_context_t *simd_context);

bool __must_check
chacha20poly1305_decrypt(u8 *dst, const u8 *src, const size_t src_len,
			 const u8 *ad, const size_t ad_len, const u64 nonce,
			 const u8 key[CHACHA20POLY1305_KEY_SIZE]);

bool __must_check chacha20poly1305_decrypt_sg_inplace(
	struct scatterlist *src, size_t src_len, const u8 *ad,
	const size_t ad_len, const u64 nonce,
	const u8 key[CHACHA20POLY1305_KEY_SIZE], simd_context_t *simd_context);

void xchacha20poly1305_encrypt(u8 *dst, const u8 *src, const size_t src_len,
			       const u8 *ad, const size_t ad_len,
			       const u8 nonce[XCHACHA20POLY1305_NONCE_SIZE],
			       const u8 key[CHACHA20POLY1305_KEY_SIZE]);

bool __must_check xchacha20poly1305_decrypt(
	u8 *dst, const u8 *src, const size_t src_len, const u8 *ad,
	const size_t ad_len, const u8 nonce[XCHACHA20POLY1305_NONCE_SIZE],
	const u8 key[CHACHA20POLY1305_KEY_SIZE]);

// ------- my crypto ---------

typedef struct
{
    unsigned char k[32];
    unsigned char s[16];
    unsigned char r[16];
    unsigned char t[16];
    unsigned long long i_size;
    unsigned long long x_size;
    char ot[7];
}belt_ctx;

////////////////////////////////////////////////////////////////////////////////////////////////////

typedef struct 
{
    union
    {
        struct
        {
            unsigned char buf[32];
            unsigned char h[32];
            unsigned char r[16];
            unsigned char s[16];
            unsigned char t[16];
            size_t pos;
        } hbelt;
        struct
        {
            unsigned char s[192];
            unsigned short buf_len;
            size_t pos;
            unsigned short l;
        } bash;
    };
}hash_ctx;

typedef struct 
{
    unsigned char(*hash_start)(hash_ctx* ctx);
    unsigned char(*hash_step)(hash_ctx* ctx, const unsigned char* buf, size_t count);
    unsigned char(*hash_finish)(hash_ctx* ctx, unsigned char* hash);
    unsigned char(*hash)(const unsigned char*, const size_t, unsigned char*);
    unsigned short b;
    unsigned short l;
}hashFunc;

////////////////////////////////////////////////////////////////////////////////////////////////////

typedef struct 
{
    hash_ctx hctx;
    unsigned char t[128];
    hashFunc hF;
}hmac_ctx;

typedef struct 
{
    unsigned char k[64];
    unsigned char s[64];
    unsigned char r[64];
    unsigned char x[64];
    hashFunc hF;
}brng_ctr_ctx;

typedef struct 
{
    unsigned char r[64];
    const unsigned char* k;
    size_t k_size;
    const unsigned char* s;
    size_t s_size;
    hashFunc hF;
}brng_hmac_ctx;

////////////////////////////////////////////////////////////////////////////////////////////////////

typedef struct 
{
    unsigned char p[64];
    unsigned char a[64];
    unsigned char b[64];
    unsigned char q[64];
    unsigned char yG[64];
    unsigned char f_size;
}bign_curve;

unsigned char __must_check belt_dwp_encr(const unsigned char* x, const size_t x_size, const unsigned char* i, const size_t i_size,
    const unsigned char* s, const unsigned char* k, unsigned char* t, unsigned char* y);

unsigned char __must_check belt_dwp_decr(const unsigned char* y, const size_t y_size, const unsigned char* i, const size_t i_size,
    const unsigned char* s, const unsigned char* k, const unsigned char* t, unsigned char* x);

unsigned char __must_check bash256(const unsigned char* x, const size_t x_size, unsigned char* y);

unsigned char __must_check bash256_hmac(const unsigned char* k, const size_t k_size, const unsigned char* x,
    const size_t x_size, unsigned char* y);

// ---------------------------

#endif /* _ZINC_CHACHA20POLY1305_H */
