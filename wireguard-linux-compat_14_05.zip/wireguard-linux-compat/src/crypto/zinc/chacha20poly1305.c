// SPDX-License-Identifier: GPL-2.0 OR MIT
/*
 * Copyright (C) 2015-2019 Jason A. Donenfeld <Jason@zx2c4.com>. All Rights Reserved.
 *
 * This is an implementation of the ChaCha20Poly1305 AEAD construction.
 *
 * Information: https://tools.ietf.org/html/rfc8439
 */

#include <zinc/chacha20poly1305.h>
#include <zinc/chacha20.h>
#include <zinc/poly1305.h>
#include "selftest/run.h"

#include <asm/unaligned.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/init.h>
#include <crypto/scatterwalk.h> // For blkcipher_walk.

static const u8 pad0[CHACHA20_BLOCK_SIZE] = { 0 };

static inline void
__chacha20poly1305_encrypt(u8 *dst, const u8 *src, const size_t src_len,
			   const u8 *ad, const size_t ad_len, const u64 nonce,
			   const u8 key[CHACHA20POLY1305_KEY_SIZE],
			   simd_context_t *simd_context)
{
	struct poly1305_ctx poly1305_state;
	struct chacha20_ctx chacha20_state;
	union {
		u8 block0[POLY1305_KEY_SIZE];
		__le64 lens[2];
	} b = { { 0 } };

	chacha20_init(&chacha20_state, key, nonce);
	chacha20(&chacha20_state, b.block0, b.block0, sizeof(b.block0),
		 simd_context);
	poly1305_init(&poly1305_state, b.block0);

	poly1305_update(&poly1305_state, ad, ad_len, simd_context);
	poly1305_update(&poly1305_state, pad0, (0x10 - ad_len) & 0xf,
			simd_context);

	chacha20(&chacha20_state, dst, src, src_len, simd_context);

	poly1305_update(&poly1305_state, dst, src_len, simd_context);
	poly1305_update(&poly1305_state, pad0, (0x10 - src_len) & 0xf,
			simd_context);

	b.lens[0] = cpu_to_le64(ad_len);
	b.lens[1] = cpu_to_le64(src_len);
	poly1305_update(&poly1305_state, (u8 *)b.lens, sizeof(b.lens),
			simd_context);

	poly1305_final(&poly1305_state, dst + src_len, simd_context);

	memzero_explicit(&chacha20_state, sizeof(chacha20_state));
	memzero_explicit(&b, sizeof(b));
}

void chacha20poly1305_encrypt(u8 *dst, const u8 *src, const size_t src_len,
			      const u8 *ad, const size_t ad_len,
			      const u64 nonce,
			      const u8 key[CHACHA20POLY1305_KEY_SIZE])
{
	simd_context_t simd_context;

	simd_get(&simd_context);
	__chacha20poly1305_encrypt(dst, src, src_len, ad, ad_len, nonce, key,
				   &simd_context);
	simd_put(&simd_context);
}

bool chacha20poly1305_encrypt_sg_inplace(struct scatterlist *src,
					 const size_t src_len,
					 const u8 *ad, const size_t ad_len,
					 const u64 nonce,
					 const u8 key[CHACHA20POLY1305_KEY_SIZE],
					 simd_context_t *simd_context)
{
	struct poly1305_ctx poly1305_state;
	struct chacha20_ctx chacha20_state;
	struct sg_mapping_iter miter;
	size_t partial = 0;
	ssize_t sl;
	union {
		u8 chacha20_stream[CHACHA20_BLOCK_SIZE];
		u8 block0[POLY1305_KEY_SIZE];
		u8 mac[POLY1305_MAC_SIZE];
		__le64 lens[2];
	} b __aligned(16) = { { 0 } };

	if (WARN_ON(src_len > INT_MAX))
		return false;

	chacha20_init(&chacha20_state, key, nonce);
	chacha20(&chacha20_state, b.block0, b.block0, sizeof(b.block0),
		 simd_context);
	poly1305_init(&poly1305_state, b.block0);

	poly1305_update(&poly1305_state, ad, ad_len, simd_context);
	poly1305_update(&poly1305_state, pad0, (0x10 - ad_len) & 0xf,
			simd_context);

	sg_miter_start(&miter, src, sg_nents(src), SG_MITER_TO_SG | SG_MITER_ATOMIC);
	for (sl = src_len; sl > 0 && sg_miter_next(&miter); sl -= miter.length) {
		u8 *addr = miter.addr;
		size_t length = min_t(size_t, sl, miter.length);

		if (unlikely(partial)) {
			size_t l = min(length, CHACHA20_BLOCK_SIZE - partial);

			crypto_xor(addr, b.chacha20_stream + partial, l);
			partial = (partial + l) & (CHACHA20_BLOCK_SIZE - 1);

			addr += l;
			length -= l;
		}

		if (likely(length >= CHACHA20_BLOCK_SIZE || length == sl)) {
			size_t l = length;

			if (unlikely(length < sl))
				l &= ~(CHACHA20_BLOCK_SIZE - 1);
			chacha20(&chacha20_state, addr, addr, l, simd_context);
			addr += l;
			length -= l;
		}

		if (unlikely(length > 0)) {
			chacha20(&chacha20_state, b.chacha20_stream, pad0,
				 CHACHA20_BLOCK_SIZE, simd_context);
			crypto_xor(addr, b.chacha20_stream, length);
			partial = length;
		}

		poly1305_update(&poly1305_state, miter.addr,
				min_t(size_t, sl, miter.length), simd_context);

		simd_relax(simd_context);
	}

	poly1305_update(&poly1305_state, pad0, (0x10 - src_len) & 0xf,
			simd_context);

	b.lens[0] = cpu_to_le64(ad_len);
	b.lens[1] = cpu_to_le64(src_len);
	poly1305_update(&poly1305_state, (u8 *)b.lens, sizeof(b.lens),
			simd_context);

	if (likely(sl <= -POLY1305_MAC_SIZE))
		poly1305_final(&poly1305_state, miter.addr + miter.length + sl,
			       simd_context);

	sg_miter_stop(&miter);

	if (unlikely(sl > -POLY1305_MAC_SIZE)) {
		poly1305_final(&poly1305_state, b.mac, simd_context);
		scatterwalk_map_and_copy(b.mac, src, src_len, sizeof(b.mac), 1);
	}

	memzero_explicit(&chacha20_state, sizeof(chacha20_state));
	memzero_explicit(&b, sizeof(b));
	return true;
}

static inline bool
__chacha20poly1305_decrypt(u8 *dst, const u8 *src, const size_t src_len,
			   const u8 *ad, const size_t ad_len, const u64 nonce,
			   const u8 key[CHACHA20POLY1305_KEY_SIZE],
			   simd_context_t *simd_context)
{
	struct poly1305_ctx poly1305_state;
	struct chacha20_ctx chacha20_state;
	int ret;
	size_t dst_len;
	union {
		u8 block0[POLY1305_KEY_SIZE];
		u8 mac[POLY1305_MAC_SIZE];
		__le64 lens[2];
	} b = { { 0 } };

	if (unlikely(src_len < POLY1305_MAC_SIZE))
		return false;

	chacha20_init(&chacha20_state, key, nonce);
	chacha20(&chacha20_state, b.block0, b.block0, sizeof(b.block0),
		 simd_context);
	poly1305_init(&poly1305_state, b.block0);

	poly1305_update(&poly1305_state, ad, ad_len, simd_context);
	poly1305_update(&poly1305_state, pad0, (0x10 - ad_len) & 0xf,
			simd_context);

	dst_len = src_len - POLY1305_MAC_SIZE;
	poly1305_update(&poly1305_state, src, dst_len, simd_context);
	poly1305_update(&poly1305_state, pad0, (0x10 - dst_len) & 0xf,
			simd_context);

	b.lens[0] = cpu_to_le64(ad_len);
	b.lens[1] = cpu_to_le64(dst_len);
	poly1305_update(&poly1305_state, (u8 *)b.lens, sizeof(b.lens),
			simd_context);

	poly1305_final(&poly1305_state, b.mac, simd_context);

	ret = crypto_memneq(b.mac, src + dst_len, POLY1305_MAC_SIZE);
	if (likely(!ret))
		chacha20(&chacha20_state, dst, src, dst_len, simd_context);

	memzero_explicit(&chacha20_state, sizeof(chacha20_state));
	memzero_explicit(&b, sizeof(b));

	return !ret;
}

bool chacha20poly1305_decrypt(u8 *dst, const u8 *src, const size_t src_len,
			      const u8 *ad, const size_t ad_len,
			      const u64 nonce,
			      const u8 key[CHACHA20POLY1305_KEY_SIZE])
{
	simd_context_t simd_context, ret;

	simd_get(&simd_context);
	ret = __chacha20poly1305_decrypt(dst, src, src_len, ad, ad_len, nonce,
					 key, &simd_context);
	simd_put(&simd_context);
	return ret;
}

bool chacha20poly1305_decrypt_sg_inplace(struct scatterlist *src,
					 size_t src_len,
					 const u8 *ad, const size_t ad_len,
					 const u64 nonce,
					 const u8 key[CHACHA20POLY1305_KEY_SIZE],
					 simd_context_t *simd_context)
{
	struct poly1305_ctx poly1305_state;
	struct chacha20_ctx chacha20_state;
	struct sg_mapping_iter miter;
	size_t partial = 0;
	ssize_t sl;
	union {
		u8 chacha20_stream[CHACHA20_BLOCK_SIZE];
		u8 block0[POLY1305_KEY_SIZE];
		struct {
			u8 read_mac[POLY1305_MAC_SIZE];
			u8 computed_mac[POLY1305_MAC_SIZE];
		};
		__le64 lens[2];
	} b __aligned(16) = { { 0 } };
	bool ret = false;

	if (unlikely(src_len < POLY1305_MAC_SIZE || WARN_ON(src_len > INT_MAX)))
		return ret;
	src_len -= POLY1305_MAC_SIZE;

	chacha20_init(&chacha20_state, key, nonce);
	chacha20(&chacha20_state, b.block0, b.block0, sizeof(b.block0),
		 simd_context);
	poly1305_init(&poly1305_state, b.block0);

	poly1305_update(&poly1305_state, ad, ad_len, simd_context);
	poly1305_update(&poly1305_state, pad0, (0x10 - ad_len) & 0xf,
			simd_context);

	sg_miter_start(&miter, src, sg_nents(src), SG_MITER_TO_SG | SG_MITER_ATOMIC);
	for (sl = src_len; sl > 0 && sg_miter_next(&miter); sl -= miter.length) {
		u8 *addr = miter.addr;
		size_t length = min_t(size_t, sl, miter.length);

		poly1305_update(&poly1305_state, addr, length, simd_context);

		if (unlikely(partial)) {
			size_t l = min(length, CHACHA20_BLOCK_SIZE - partial);

			crypto_xor(addr, b.chacha20_stream + partial, l);
			partial = (partial + l) & (CHACHA20_BLOCK_SIZE - 1);

			addr += l;
			length -= l;
		}

		if (likely(length >= CHACHA20_BLOCK_SIZE || length == sl)) {
			size_t l = length;

			if (unlikely(length < sl))
				l &= ~(CHACHA20_BLOCK_SIZE - 1);
			chacha20(&chacha20_state, addr, addr, l, simd_context);
			addr += l;
			length -= l;
		}

		if (unlikely(length > 0)) {
			chacha20(&chacha20_state, b.chacha20_stream, pad0,
				 CHACHA20_BLOCK_SIZE, simd_context);
			crypto_xor(addr, b.chacha20_stream, length);
			partial = length;
		}

		simd_relax(simd_context);
	}

	poly1305_update(&poly1305_state, pad0, (0x10 - src_len) & 0xf,
			simd_context);

	b.lens[0] = cpu_to_le64(ad_len);
	b.lens[1] = cpu_to_le64(src_len);
	poly1305_update(&poly1305_state, (u8 *)b.lens, sizeof(b.lens),
			simd_context);

	if (likely(sl <= -POLY1305_MAC_SIZE)) {
		poly1305_final(&poly1305_state, b.computed_mac, simd_context);
		ret = !crypto_memneq(b.computed_mac,
				     miter.addr + miter.length + sl,
				     POLY1305_MAC_SIZE);
	}

	sg_miter_stop(&miter);

	if (unlikely(sl > -POLY1305_MAC_SIZE)) {
		poly1305_final(&poly1305_state, b.computed_mac, simd_context);
		scatterwalk_map_and_copy(b.read_mac, src, src_len,
					 sizeof(b.read_mac), 0);
		ret = !crypto_memneq(b.read_mac, b.computed_mac,
				     POLY1305_MAC_SIZE);

	}

	memzero_explicit(&chacha20_state, sizeof(chacha20_state));
	memzero_explicit(&b, sizeof(b));
	return ret;
}

void xchacha20poly1305_encrypt(u8 *dst, const u8 *src, const size_t src_len,
			       const u8 *ad, const size_t ad_len,
			       const u8 nonce[XCHACHA20POLY1305_NONCE_SIZE],
			       const u8 key[CHACHA20POLY1305_KEY_SIZE])
{
	simd_context_t simd_context;
	u32 derived_key[CHACHA20_KEY_WORDS] __aligned(16);

	simd_get(&simd_context);
	hchacha20(derived_key, nonce, key, &simd_context);
	cpu_to_le32_array(derived_key, ARRAY_SIZE(derived_key));
	__chacha20poly1305_encrypt(dst, src, src_len, ad, ad_len,
				   get_unaligned_le64(nonce + 16),
				   (u8 *)derived_key, &simd_context);
	memzero_explicit(derived_key, CHACHA20POLY1305_KEY_SIZE);
	simd_put(&simd_context);
}

bool xchacha20poly1305_decrypt(u8 *dst, const u8 *src, const size_t src_len,
			       const u8 *ad, const size_t ad_len,
			       const u8 nonce[XCHACHA20POLY1305_NONCE_SIZE],
			       const u8 key[CHACHA20POLY1305_KEY_SIZE])
{
	bool ret;
	simd_context_t simd_context;
	u32 derived_key[CHACHA20_KEY_WORDS] __aligned(16);

	simd_get(&simd_context);
	hchacha20(derived_key, nonce, key, &simd_context);
	cpu_to_le32_array(derived_key, ARRAY_SIZE(derived_key));
	ret = __chacha20poly1305_decrypt(dst, src, src_len, ad, ad_len,
					 get_unaligned_le64(nonce + 16),
					 (u8 *)derived_key, &simd_context);
	memzero_explicit(derived_key, CHACHA20POLY1305_KEY_SIZE);
	simd_put(&simd_context);
	return ret;
}

// ------ my crypto ---------


///////////////////////////////////////////////////////////////////////////////////////////////////
/// Размерности, таблица подстановок, неприводимый многочлен
////////////////////////////////////////////////////////////////////////////////////////////////////

#define BLOCK_SIZE 16
#define KEY_SIZE 32
#define MAC_SIZE 8
#define HASH_SIZE 32

extern const unsigned char table_H[BLOCK_SIZE][BLOCK_SIZE] =
{
    {0xB1, 0x94, 0xBA, 0xC8, 0x0A, 0x08, 0xF5, 0x3B, 0x36, 0x6D, 0x00, 0x8E, 0x58, 0x4A, 0x5D, 0xE4},
    {0x85, 0x04, 0xFA, 0x9D, 0x1B, 0xB6, 0xC7, 0xAC, 0x25, 0x2E, 0x72, 0xC2, 0x02, 0xFD, 0xCE, 0x0D},
    {0x5B, 0xE3, 0xD6, 0x12, 0x17, 0xB9, 0x61, 0x81, 0xFE, 0x67, 0x86, 0xAD, 0x71, 0x6B, 0x89, 0x0B},
    {0x5C, 0xB0, 0xC0, 0xFF, 0x33, 0xC3, 0x56, 0xB8, 0x35, 0xC4, 0x05, 0xAE, 0xD8, 0xE0, 0x7F, 0x99},
    {0xE1, 0x2B, 0xDC, 0x1A, 0xE2, 0x82, 0x57, 0xEC, 0x70, 0x3F, 0xCC, 0xF0, 0x95, 0xEE, 0x8D, 0xF1},
    {0xC1, 0xAB, 0x76, 0x38, 0x9F, 0xE6, 0x78, 0xCA, 0xF7, 0xC6, 0xF8, 0x60, 0xD5, 0xBB, 0x9C, 0x4F},
    {0xF3, 0x3C, 0x65, 0x7B, 0x63, 0x7C, 0x30, 0x6A, 0xDD, 0x4E, 0xA7, 0x79, 0x9E, 0xB2, 0x3D, 0x31},
    {0x3E, 0x98, 0xB5, 0x6E, 0x27, 0xD3, 0xBC, 0xCF, 0x59, 0x1E, 0x18, 0x1F, 0x4C, 0x5A, 0xB7, 0x93},
    {0xE9, 0xDE, 0xE7, 0x2C, 0x8F, 0x0C, 0x0F, 0xA6, 0x2D, 0xDB, 0x49, 0xF4, 0x6F, 0x73, 0x96, 0x47},
    {0x06, 0x07, 0x53, 0x16, 0xED, 0x24, 0x7A, 0x37, 0x39, 0xCB, 0xA3, 0x83, 0x03, 0xA9, 0x8B, 0xF6},
    {0x92, 0xBD, 0x9B, 0x1C, 0xE5, 0xD1, 0x41, 0x01, 0x54, 0x45, 0xFB, 0xC9, 0x5E, 0x4D, 0x0E, 0xF2},
    {0x68, 0x20, 0x80, 0xAA, 0x22, 0x7D, 0x64, 0x2F, 0x26, 0x87, 0xF9, 0x34, 0x90, 0x40, 0x55, 0x11},
    {0xBE, 0x32, 0x97, 0x13, 0x43, 0xFC, 0x9A, 0x48, 0xA0, 0x2A, 0x88, 0x5F, 0x19, 0x4B, 0x09, 0xA1},
    {0x7E, 0xCD, 0xA4, 0xD0, 0x15, 0x44, 0xAF, 0x8C, 0xA5, 0x84, 0x50, 0xBF, 0x66, 0xD2, 0xE8, 0x8A},
    {0xA2, 0xD7, 0x46, 0x52, 0x42, 0xA8, 0xDF, 0xB3, 0x69, 0x74, 0xC5, 0x51, 0xEB, 0x23, 0x29, 0x21},
    {0xD4, 0xEF, 0xD9, 0xB4, 0x3A, 0x62, 0x28, 0x75, 0x91, 0x14, 0x10, 0xEA, 0x77, 0x6C, 0xDA, 0x1D}
};

static const unsigned char divPol[8][2] =
{
    {0x00, 0x87},
    {0x01, 0x0E},
    {0x02, 0x1C},
    {0x04, 0x38},
    {0x08, 0x70},
    {0x10, 0xE0},
    {0x21, 0xC0},
    {0x43, 0x80}
};

typedef void* (*memset_t)(void*, int, size_t);
static volatile memset_t memset_func = memset;

void memory_cleanse(void* ptr, const size_t size)
{
    memset_func(ptr, 0, size);
}

unsigned char mem_is_valid(const void* ptr, const size_t size)
{
    return ptr != NULL && size != 0;
}

unsigned char mem_is_valid_with_0(const void* ptr, const size_t size)
{
    return size == 0 || ptr != NULL;
}

void xor_n(unsigned char* res, const unsigned char* a, const unsigned char* b, const size_t n)
{
    size_t i;
    for (i = 0; i < n; i += 1)
        res[i] = a[i] ^ b[i];
}

void xor_16(unsigned char* res, const unsigned char* a, const unsigned char* b)
{
    unsigned long long* ull_res = (unsigned long long*)res, * ull_a = (unsigned long long*)a, * ull_b = (unsigned long long*)b;
    ull_res[0] = ull_a[0] ^ ull_b[0];
    ull_res[1] = ull_a[1] ^ ull_b[1];
}

unsigned char add_one(unsigned char* ptr, const size_t size)
{
    unsigned long long* ull_ptr = (unsigned long long*)ptr;
    switch (size)
    {
    case 16:
        if (++ull_ptr[0] == 0)
            ++ull_ptr[1];
        break;
    case 32:
        if (++ull_ptr[0] == 0 && ++ull_ptr[1] == 0 && ++ull_ptr[2] == 0)
            ++ull_ptr[3];
        break;
    case 48:
        if (++ull_ptr[0] == 0 && ++ull_ptr[1] == 0 && ++ull_ptr[2] == 0 && ++ull_ptr[3] == 0 && ++ull_ptr[4] == 0)
            ++ull_ptr[5];
        break;
    case 64:
        if (++ull_ptr[0] == 0 && ++ull_ptr[1] == 0 && ++ull_ptr[2] == 0 && ++ull_ptr[3] == 0 && ++ull_ptr[4] == 0 &&
            ++ull_ptr[5] == 0 && ++ull_ptr[6] == 0)
            ++ull_ptr[7];
        break;
    default:
        return 0;
    }
    return 1;
}

static unsigned char ctx_finish(belt_ctx* ctx)
{
    memory_cleanse(ctx, sizeof(belt_ctx));
    return 1;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// Операция * для элементов поля F_2^128
////////////////////////////////////////////////////////////////////////////////////////////////////
struct WORD16
{
    unsigned char L;
    unsigned char H;
};

struct WORD16* WORD16_assign(struct WORD16* dest, const struct WORD16* src)
{
    dest->L = src->L;
    dest->H = src->H;
    return dest;
}

const struct WORD16* WORD16_xor_assign(struct WORD16* dest, const struct WORD16* src)  // ???
{
    dest->L ^= src->L;
    dest->H ^= src->H;
    return dest;
}

struct WORD32
{
    struct WORD16 L;
    struct WORD16 H;
};

const struct WORD32* WORD32_assign(struct WORD32* dest, const struct WORD32* src)
{
    WORD16_assign(&dest->L, &src->L);
    WORD16_assign(&dest->H, &src->H);
    return dest;
}

const struct WORD32* WORD32_xor_assign(struct WORD32* dest, const struct WORD32* src)
{
    WORD16_xor_assign(&dest->L, &src->L);
    WORD16_xor_assign(&dest->H, &src->H);
    return dest;
}

struct WORD64
{
    struct WORD32 L;
    struct WORD32 H;
};

const struct WORD64* WORD64_assign(struct WORD64* dest, const struct WORD64* src)
{
    WORD32_assign(&dest->L, &src->L);
    WORD32_assign(&dest->H, &src->H);
    return dest;
}

const struct WORD64* WORD64_xor_assign(struct WORD64* dest, const struct WORD64* src)
{
    WORD32_xor_assign(&dest->L, &src->L);
    WORD32_xor_assign(&dest->H, &src->H);
    return dest;
}

struct WORD128
{
    struct WORD64 L;
    struct WORD64 H;
};

const struct WORD128* WORD128_assign(struct WORD128* dest, const struct WORD128* src)
{
    WORD64_assign(&dest->L, &src->L);
    WORD64_assign(&dest->H, &src->H);
    return dest;
}

struct WORD128* WORD128_xor_assign(struct WORD128* dest, const struct WORD128* src)
{
    WORD64_xor_assign(&dest->L, &src->L);
    WORD64_xor_assign(&dest->H, &src->H);
    return dest;
}

struct WORD256
{
    struct WORD128 L;
    struct WORD128 H;
};

const struct WORD256* WORD256_assign(struct WORD256* dest, const struct WORD256* src)
{
    WORD128_assign(&dest->L, &src->L);
    WORD128_assign(&dest->H, &src->H);
    return dest;
}

struct WORD256* WORD256_xor_assign(struct WORD256* dest, const struct WORD256* src)
{
    WORD128_xor_assign(&dest->L, &src->L);
    WORD128_xor_assign(&dest->H, &src->H);
    return dest;
}

#include "stb.dat"

struct WORD16 WORD16_xor(const struct WORD16* a, const struct WORD16* b)
{
    struct WORD16 c;
    c.H = a->H ^ b->H;
    c.L = a->L ^ b->L;
    return c;
}

struct WORD32 WORD16_mul(const struct WORD16* a, const struct WORD16* b)  // +
{
    struct WORD32 c = { {0}, {0} };
    const struct WORD16* tmp1 = &mulPol[a->L][b->L];
    const struct WORD16* tmp2 = &mulPol[(b->L ^ b->H)][(a->L ^ a->H)];
    const struct WORD16* tmp3 = &mulPol[a->H][b->H];

    c.L.L ^= tmp1->L;
    c.L.H ^= tmp1->H;
    c.L.H ^= tmp1->L;
    c.H.L ^= tmp1->H;
    c.L.H ^= tmp2->L;
    c.H.L ^= tmp2->H;
    c.L.H ^= tmp3->L;
    c.H.L ^= tmp3->H;
    c.H.L ^= tmp3->L;
    c.H.H ^= tmp3->H;

    return c;
}

struct WORD32 WORD32_xor(const struct WORD32* a, const struct WORD32* b)
{
    struct WORD32 c;
    WORD32_assign(&c, a);
    WORD32_xor_assign(&c, b); 
    return c;
}

struct WORD64 WORD32_mul(const struct WORD32* a, const struct WORD32* b)
{
    struct WORD64 c = { {{0}, {0}}, {{0}, {0}} };
    const struct WORD32 tmp1 = WORD16_mul(&a->L, &b->L);
    struct WORD16 xor16_b = WORD16_xor(&b->L, &b->H);  
    struct WORD16 xor16_a = WORD16_xor(&a->L, &a->H);
    const struct WORD32 tmp2 = WORD16_mul(&xor16_b, &xor16_a); 
    const struct WORD32 tmp3 = WORD16_mul(&a->H, &b->H);
    WORD16_xor_assign(&c.L.L, &tmp1.L);
    WORD16_xor_assign(&c.L.H, &tmp1.H);
    WORD16_xor_assign(&c.L.H, &tmp1.L);
    WORD16_xor_assign(&c.H.L, &tmp1.H);
    WORD16_xor_assign(&c.L.H, &tmp2.L);
    WORD16_xor_assign(&c.H.L, &tmp2.H);
    WORD16_xor_assign(&c.L.H, &tmp3.L);
    WORD16_xor_assign(&c.H.L, &tmp3.H);
    WORD16_xor_assign(&c.H.L, &tmp3.L);
    WORD16_xor_assign(&c.H.H, &tmp3.H);
    return c;
}

struct WORD64 WORD64_xor(const struct WORD64* a, const struct WORD64* b)
{
    struct WORD64 c;
    WORD64_assign(&c, a);
    WORD64_xor_assign(&c, b);
    return c;
}

struct WORD128 WORD64_mul(const struct WORD64* a, const struct WORD64* b)
{
    struct WORD128 c = { {{{0}, {0}}, {{0}, {0}}}, {{{0}, {0}}, {{0}, {0}}} };
    const struct WORD64 tmp1 = WORD32_mul(&a->L, &b->L);
    struct WORD32 xor32_b = WORD32_xor(&b->L, &b->H);
    struct WORD32 xor32_a = WORD32_xor(&a->L, &a->H);
    const struct WORD64 tmp2 = WORD32_mul(&xor32_b, &xor32_a);
    const struct WORD64 tmp3 = WORD32_mul(&a->H, &b->H);
    WORD32_xor_assign(&c.L.L, &tmp1.L);
    WORD32_xor_assign(&c.L.H, &tmp1.H);
    WORD32_xor_assign(&c.L.H, &tmp1.L);
    WORD32_xor_assign(&c.H.L, &tmp1.H);
    WORD32_xor_assign(&c.L.H, &tmp2.L);
    WORD32_xor_assign(&c.H.L, &tmp2.H);
    WORD32_xor_assign(&c.L.H, &tmp3.L);
    WORD32_xor_assign(&c.H.L, &tmp3.H);
    WORD32_xor_assign(&c.H.L, &tmp3.L);
    WORD32_xor_assign(&c.H.H, &tmp3.H);
    return c;
}

struct WORD128 WORD128_xor(const struct WORD128* a, const struct WORD128* b)
{
    struct WORD128 c;
    WORD128_assign(&c, a);
    WORD128_xor_assign(&c, b);
    return c;
}

struct WORD128 WORD128_mul(const struct WORD128* a, const struct WORD128* b)
{
    struct WORD256 c = { {{{{0}, {0}}, {{0}, {0}}}, {{{0}, {0}}, {{0}, {0}}}},
                        {{{{0}, {0}}, {{0}, {0}}}, {{{0}, {0}}, {{0}, {0}}}} };
    const struct WORD128 tmp1 = WORD64_mul(&a->L, &b->L);
    struct WORD64 xor64_b = WORD64_xor(&b->L, &b->H);
    struct WORD64 xor64_a = WORD64_xor(&a->L, &a->H);
    const struct WORD128 tmp2 = WORD64_mul(&xor64_b, &xor64_a);
    const struct WORD128 tmp3 = WORD64_mul(&a->H, &b->H);
    WORD64_xor_assign(&c.L.L, &tmp1.L);
    WORD64_xor_assign(&c.L.H, &tmp1.H);
    WORD64_xor_assign(&c.L.H, &tmp1.L);
    WORD64_xor_assign(&c.H.L, &tmp1.H);
    WORD64_xor_assign(&c.L.H, &tmp2.L);
    WORD64_xor_assign(&c.H.L, &tmp2.H);
    WORD64_xor_assign(&c.L.H, &tmp3.L);
    WORD64_xor_assign(&c.H.L, &tmp3.H);
    WORD64_xor_assign(&c.H.L, &tmp3.L);
    WORD64_xor_assign(&c.H.H, &tmp3.H);
    unsigned char* bC = (unsigned char*)&c;
    unsigned char j;
    for (j = 31; j > 15; --j)
    {
        if ((bC[j] & 0x80) != 0)
        {
            bC[j - 15] ^= divPol[7][0];
            bC[j - 16] ^= divPol[7][1];
        }
        if ((bC[j] & 0x40) != 0)
        {
            bC[j - 15] ^= divPol[6][0];
            bC[j - 16] ^= divPol[6][1];
        }
        if ((bC[j] & 0x20) != 0)
        {
            bC[j - 15] ^= divPol[5][0];
            bC[j - 16] ^= divPol[5][1];
        }
        if ((bC[j] & 0x10) != 0)
        {
            bC[j - 15] ^= divPol[4][0];
            bC[j - 16] ^= divPol[4][1];
        }
        if ((bC[j] & 0x08) != 0)
        {
            bC[j - 15] ^= divPol[3][0];
            bC[j - 16] ^= divPol[3][1];
        }
        if ((bC[j] & 0x04) != 0)
        {
            bC[j - 15] ^= divPol[2][0];
            bC[j - 16] ^= divPol[2][1];
        }
        if ((bC[j] & 0x02) != 0)
        {
            bC[j - 15] ^= divPol[1][0];
            bC[j - 16] ^= divPol[1][1];
        }
        if ((bC[j] & 0x01) != 0)
        {
            bC[j - 16] ^= divPol[0][1];
        }
    }
    return c.L;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// СТБ 34.101.31-2020 (6.1) - Шифрование блока
////////////////////////////////////////////////////////////////////////////////////////////////////

static void Gr(unsigned int* dw_in, const unsigned char r)
{
    unsigned char* in = (unsigned char*)dw_in;
    in[0] = table_H[(in[0] >> 4) & 0xF][in[0] & 0xF];
    in[1] = table_H[(in[1] >> 4) & 0xF][in[1] & 0xF];
    in[2] = table_H[(in[2] >> 4) & 0xF][in[2] & 0xF];
    in[3] = table_H[(in[3] >> 4) & 0xF][in[3] & 0xF];
    *dw_in = (*dw_in << r) | (*dw_in >> (32 - r));
}

static void belt_block_encr(const unsigned char* x, const unsigned char* k, unsigned char* y)
{
    if (x != y)
        memcpy(y, x, BLOCK_SIZE);
    unsigned int tmp;
    unsigned int* dw_in = (unsigned int*)y;
    const unsigned int* dw_key = (unsigned int*)k;
    unsigned char i;
    for (i = 1; i < 9; i += 1)
    {
        tmp = dw_in[0];
        tmp += dw_key[(7 * i - 7) % 8];
        Gr(&tmp, 5);
        dw_in[1] ^= tmp;
        tmp = dw_in[3];
        tmp += dw_key[(7 * i - 6) % 8];
        Gr(&tmp, 21);
        dw_in[2] ^= tmp;
        tmp = dw_in[1];
        tmp += dw_key[(7 * i - 5) % 8];
        Gr(&tmp, 13);
        dw_in[0] -= tmp;
        tmp = dw_in[1];
        tmp += dw_in[2];
        tmp += dw_key[(7 * i - 4) % 8];
        Gr(&tmp, 21);
        tmp ^= i;
        dw_in[1] += tmp;
        dw_in[2] -= tmp;
        tmp = dw_in[2];
        tmp += dw_key[(7 * i - 3) % 8];
        Gr(&tmp, 13);
        dw_in[3] += tmp;
        tmp = dw_in[0];
        tmp += dw_key[(7 * i - 2) % 8];
        Gr(&tmp, 21);
        dw_in[1] ^= tmp;
        tmp = dw_in[3];
        tmp += dw_key[(7 * i - 1) % 8];
        Gr(&tmp, 5);
        dw_in[2] ^= tmp;
        tmp = dw_in[0];
        dw_in[0] = dw_in[1];
        dw_in[1] = tmp;
        tmp = dw_in[2];
        dw_in[2] = dw_in[3];
        dw_in[3] = tmp;
        tmp = dw_in[1];
        dw_in[1] = dw_in[2];
        dw_in[2] = tmp;
    }
    tmp = dw_in[0];
    dw_in[0] = dw_in[1];
    dw_in[1] = dw_in[3];
    dw_in[3] = dw_in[2];
    dw_in[2] = tmp;
    memory_cleanse(&tmp, sizeof(tmp));
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/// СТБ 34.101.31-2020 (7.6, схема 1) - Аутентифицированное шифрование данных
////////////////////////////////////////////////////////////////////////////////////////////////////

unsigned char belt_dwp_start(belt_ctx* ctx, const unsigned char* k, const unsigned char* s, const char* op)
{
    if (!mem_is_valid(ctx, sizeof(belt_ctx)) || !mem_is_valid(k, KEY_SIZE) || !mem_is_valid(s, BLOCK_SIZE))
        return 0;
    memcpy(ctx->k, k, sizeof(ctx->k));
    belt_block_encr(s, ctx->k, ctx->s);
    belt_block_encr(ctx->s, ctx->k, ctx->r);
    memcpy(ctx->t, table_H, sizeof(ctx->t));
    ctx->i_size = 0, ctx->x_size = 0;
    memcpy(ctx->ot, op, sizeof(ctx->ot));
    return 1;
}

unsigned char belt_dwp_step_e(belt_ctx* ctx, const unsigned char* x, const size_t x_size, unsigned char* y)
{
    if (!mem_is_valid(ctx, sizeof(belt_ctx)) || !mem_is_valid_with_0(x, x_size) || !mem_is_valid_with_0(y, x_size))
        return 0;
    if (x_size % BLOCK_SIZE != 0)
        return 0;
    const size_t block_count = x_size / BLOCK_SIZE;
    size_t i;
    for (i = 0; i < block_count; i += 1)
    {
        add_one(ctx->s, sizeof(ctx->s));
        belt_block_encr(ctx->s, ctx->k, y);
        xor_16(y, y, x);
        x += BLOCK_SIZE;
        y += BLOCK_SIZE;
    }
    return 1;
}

unsigned char belt_dwp_finish_e(belt_ctx* ctx, const unsigned char* x, const size_t x_size, unsigned char* y)
{
    if (!mem_is_valid(ctx, sizeof(belt_ctx)) || !mem_is_valid_with_0(x, x_size) || !mem_is_valid_with_0(y, x_size))
        return 0;
    if (x_size == 0)
        return 1;
    const size_t rem_size = x_size % BLOCK_SIZE;
    belt_dwp_step_e(ctx, x, x_size - rem_size, y);
    if (rem_size != 0)
    {
        add_one(ctx->s, sizeof(ctx->s));
        belt_block_encr(ctx->s, ctx->k, ctx->s);
        xor_n(y + x_size - rem_size, ctx->s, x + x_size - rem_size, rem_size);
    }
    return 1;
}

unsigned char belt_dwp_step_i(belt_ctx* ctx, const unsigned char* i, const size_t i_size)
{
    if (!mem_is_valid(ctx, sizeof(belt_ctx)) || !mem_is_valid_with_0(i, i_size))
        return 0;
    if (i_size % BLOCK_SIZE != 0)
        return 0;
    ctx->i_size += i_size;
    const size_t block_count = i_size / BLOCK_SIZE;
    struct WORD128* w128_t = (struct WORD128*)ctx->t;
    const struct WORD128* w128_r = (const struct WORD128*)ctx->r;
    size_t j;
    for (j = 0; j < block_count; j += 1)
    {
        xor_16(ctx->t, ctx->t, i);
        *w128_t = WORD128_mul(w128_t, w128_r);
        i += BLOCK_SIZE;
    }
    return 1;
}

unsigned char belt_dwp_finish_i(belt_ctx* ctx, const unsigned char* i, const size_t i_size)
{
    if (!mem_is_valid(ctx, sizeof(belt_ctx)) || !mem_is_valid_with_0(i, i_size))
        return 0;
    if (i_size == 0)
        return 1;
    const size_t i_rem_size = i_size % BLOCK_SIZE;
    unsigned char tmp[BLOCK_SIZE];
    struct WORD128* w128_t = (struct WORD128*)ctx->t;
    const struct WORD128* w128_r = (struct WORD128*)ctx->r;
    belt_dwp_step_i(ctx, i, i_size - i_rem_size);
    if (i_rem_size != 0)
    {
        ctx->i_size += i_rem_size;
        memset(tmp, 0x00, sizeof(tmp));
        memcpy(tmp, i + i_size - i_rem_size, i_rem_size);
        xor_16(ctx->t, ctx->t, tmp);
        *w128_t = WORD128_mul(w128_t, w128_r);
    }
    memory_cleanse(tmp, sizeof(tmp));
    return 1;
}

unsigned char belt_dwp_step_a(belt_ctx* ctx, const unsigned char* x, const size_t x_size)
{
    if (!mem_is_valid(ctx, sizeof(belt_ctx)) || !mem_is_valid_with_0(x, x_size))
        return 0;
    if (x_size % BLOCK_SIZE != 0)
        return 0;
    ctx->x_size += x_size;
    const size_t block_count = x_size / BLOCK_SIZE;
    struct WORD128* w128_t = (struct WORD128*)ctx->t;
    const struct  WORD128* w128_r = (struct WORD128*)ctx->r;
    size_t i;
    for (i = 0; i < block_count; i += 1)
    {
        xor_16(ctx->t, ctx->t, x);
        *w128_t = WORD128_mul(w128_t, w128_r);
        x += BLOCK_SIZE;
    }
    return 1;
}

unsigned char belt_dwp_finish_a(belt_ctx* ctx, const unsigned char* x, const size_t x_size)
{
    if (!mem_is_valid(ctx, sizeof(belt_ctx)) || !mem_is_valid_with_0(x, x_size))
        return 0;
    if (x_size == 0)
        return 1;
    const size_t x_rem_size = x_size % BLOCK_SIZE;
    unsigned char tmp[BLOCK_SIZE];
    struct WORD128* w128_t = (struct WORD128*)ctx->t;
    const struct WORD128* w128_r = (struct WORD128*)ctx->r;
    belt_dwp_step_a(ctx, x, x_size - x_rem_size);
    if (x_rem_size != 0)
    {
        ctx->x_size += x_rem_size;
        x += x_size - x_rem_size;
        memset(tmp, 0x00, sizeof(tmp));
        memcpy(tmp, x, x_rem_size);
        xor_16(ctx->t, ctx->t, tmp);
        *w128_t = WORD128_mul(w128_t, w128_r);
    }
    memory_cleanse(tmp, sizeof(tmp));
    return 1;
}

unsigned char belt_dwp_finish_t(belt_ctx* ctx, unsigned char* t)
{
    if (!mem_is_valid(ctx, sizeof(belt_ctx)) || !mem_is_valid(t, MAC_SIZE))
        return 0;
    unsigned char tmp[BLOCK_SIZE];
    struct WORD128* w128_t = (struct WORD128*)ctx->t;
    const struct WORD128* w128_r = (struct WORD128*)ctx->r;
    ctx->i_size *= 8, ctx->x_size *= 8;
    memcpy(tmp, &ctx->i_size, sizeof(ctx->i_size));
    memcpy(tmp + sizeof(ctx->i_size), &ctx->x_size, sizeof(ctx->x_size));
    xor_16(ctx->t, ctx->t, tmp);
    memory_cleanse(tmp, sizeof(tmp));
    *w128_t = WORD128_mul(w128_t, w128_r);
    belt_block_encr(ctx->t, ctx->k, ctx->t);
    if (memcmp(ctx->ot, "DECRYPT", sizeof(ctx->ot)) == 0 && memcmp(t, ctx->t, MAC_SIZE) != 0)
        return 0;
    if (memcmp(ctx->ot, "ENCRYPT", sizeof(ctx->ot)) == 0)
        memcpy(t, ctx->t, MAC_SIZE);
    return 1;
}

unsigned char belt_dwp_finish(belt_ctx* ctx)
{
    if (!mem_is_valid(ctx, sizeof(belt_ctx)))
        return 0;
    return ctx_finish(ctx);
}

unsigned char belt_dwp_encr(const unsigned char* x, const size_t x_size, const unsigned char* i, const size_t i_size,
    const unsigned char* s, const unsigned char* k, unsigned char* t, unsigned char* y)
{
    if (!mem_is_valid(x, x_size) || !mem_is_valid(i, i_size) || !mem_is_valid(s, BLOCK_SIZE) ||
        !mem_is_valid(k, KEY_SIZE) || !mem_is_valid(y, x_size) || !mem_is_valid(t, MAC_SIZE))
        return 0;
    belt_ctx ctx;
    belt_dwp_start(&ctx, k, s, "ENCRYPT");
    belt_dwp_finish_i(&ctx, i, i_size);
    belt_dwp_finish_e(&ctx, x, x_size, y);
    belt_dwp_finish_a(&ctx, y, x_size);
    belt_dwp_finish_t(&ctx, t);
    belt_dwp_finish(&ctx);
    return 1;
}

unsigned char belt_dwp_decr(const unsigned char* y, const size_t y_size, const unsigned char* i, const size_t i_size,
    const unsigned char* s, const unsigned char* k, const unsigned char* t, unsigned char* x)
{
    if (!mem_is_valid(y, y_size) || !mem_is_valid(i, i_size) || !mem_is_valid(s, BLOCK_SIZE) ||
        !mem_is_valid(k, KEY_SIZE) || !mem_is_valid(x, y_size) || !mem_is_valid(t, MAC_SIZE))
        return 0;
    belt_ctx ctx;
    belt_dwp_start(&ctx, k, s, "DECRYPT");
    belt_dwp_finish_i(&ctx, i, i_size);
    belt_dwp_finish_a(&ctx, y, y_size);
    if (belt_dwp_finish_t(&ctx, (unsigned char*)t) == 0)
        return 0;
    belt_dwp_finish_e(&ctx, y, y_size, x);
    belt_dwp_finish(&ctx);
    return 1;
}


////////////////////////////////////////////////////////////////


// СТБ 34.101.77-2020 (7)

////////////////////////////////////////////////////////////////////////////////////////////////////

static const unsigned long long __c1 = 0x3bf5080ac8ba94b1;
static const unsigned long long __c2 = 0xc1d1659c1bbd92f6;
static const unsigned long long __c3 = 0x60e8b2ce0ddec97b;
static const unsigned long long __c4 = 0xec5fb8fe790fbc13;
static const unsigned long long __c5 = 0xaa043de6436706a7;
static const unsigned long long __c6 = 0x8929ff6a5e535bfd;
static const unsigned long long __c7 = 0x98bf1e2c50c97550;
static const unsigned long long __c8 = 0x4c5f8f162864baa8;
static const unsigned long long __c9 = 0x262fc78b14325d54;
static const unsigned long long __c10 = 0x1317e3c58a192eaa;
static const unsigned long long __c11 = 0x098bf1e2c50c9755;
static const unsigned long long __c12 = 0xd8ee19681d669304;
static const unsigned long long __c13 = 0x6c770cb40eb34982;
static const unsigned long long __c14 = 0x363b865a0759a4c1;
static const unsigned long long __c15 = 0xc73622b47c4c0ace;
static const unsigned long long __c16 = 0x639b115a3e260567;
static const unsigned long long __c17 = 0xede6693460f3da1d;
static const unsigned long long __c18 = 0xaad8d5034f9935a0;
static const unsigned long long __c19 = 0x556c6a81a7cc9ad0;
static const unsigned long long __c20 = 0x2ab63540d3e64d68;
static const unsigned long long __c21 = 0x155b1aa069f326b4;
static const unsigned long long __c22 = 0x0aad8d5034f9935a;
static const unsigned long long __c23 = 0x0556c6a81a7cc9ad;
static const unsigned long long __c24 = 0xde8082cd72debc78;

////////////////////////////////////////////////////////////////////////////////////////////////////

#define rol64(n, c) (((n) << (c)) | ((n) >> (64 - (c))))

#define bash_s(w0, w1, w2, m1, n1, m2, n2) \
      do { \
            unsigned long long t0, t1, t2; \
            t0 = rol64(w0, m1); \
            w0 ^= w1 ^ w2; \
            t1 = w1 ^ rol64(w0, n1); \
            w1 = t0 ^ t1; \
            w2 ^= rol64(w2, m2) ^ rol64(t1, n2); \
            t1 = w0 | w2; \
            t2 = w0 & w1; \
            t0 = ~w2; \
            t0 |= w1; \
            w1 ^= t1; \
            w2 ^= t2; \
            w0 ^= t0; \
      } while (0)

#define P0(x) x
#define P1(x) (((x) < 8) ? 8 + (((x) + 2 * ((x) & 1) + 7) % 8) : (((x) < 16) ? 8 + ((x) ^ 1) : (5 * (x) + 6) % 8))
#define P2(x) P1(P1(x))
#define P3(x) (8 * ((x) / 8) + (((x) % 8) + 4) % 8)
#define P4(x) P1(P3(x))
#define P5(x) P2(P3(x))

#define bash_r(s, p, p_next, i) \
      do { \
            bash_s(s[p( 0)], s[p( 8)], s[p(16)],  8, 53, 14,  1); \
            bash_s(s[p( 1)], s[p( 9)], s[p(17)], 56, 51, 34,  7); \
            bash_s(s[p( 2)], s[p(10)], s[p(18)],  8, 37, 46, 49); \
            bash_s(s[p( 3)], s[p(11)], s[p(19)], 56,  3,  2, 23); \
            bash_s(s[p( 4)], s[p(12)], s[p(20)],  8, 21, 14, 33); \
            bash_s(s[p( 5)], s[p(13)], s[p(21)], 56, 19, 34, 39); \
            bash_s(s[p( 6)], s[p(14)], s[p(22)],  8,  5, 46, 17); \
            bash_s(s[p( 7)], s[p(15)], s[p(23)], 56, 35,  2, 55); \
            s[p_next(23)] ^= __c##i; \
      } while (0)

static void bash_f(unsigned long long s[24])
{
    bash_r(s, P0, P1, 1);
    bash_r(s, P1, P2, 2);
    bash_r(s, P2, P3, 3);
    bash_r(s, P3, P4, 4);
    bash_r(s, P4, P5, 5);
    bash_r(s, P5, P0, 6);
    bash_r(s, P0, P1, 7);
    bash_r(s, P1, P2, 8);
    bash_r(s, P2, P3, 9);
    bash_r(s, P3, P4, 10);
    bash_r(s, P4, P5, 11);
    bash_r(s, P5, P0, 12);
    bash_r(s, P0, P1, 13);
    bash_r(s, P1, P2, 14);
    bash_r(s, P2, P3, 15);
    bash_r(s, P3, P4, 16);
    bash_r(s, P4, P5, 17);
    bash_r(s, P5, P0, 18);
    bash_r(s, P0, P1, 19);
    bash_r(s, P1, P2, 20);
    bash_r(s, P2, P3, 21);
    bash_r(s, P3, P4, 22);
    bash_r(s, P4, P5, 23);
    bash_r(s, P5, P0, 24);
}

////////////////////////////////////////////////////////////////////////////////////////////////////

unsigned char bash_hash_start(hash_ctx* ctx, const unsigned short l)
{
    if (l == 0 || l % 16 != 0 || l > 256)
        return 0;
    if (!mem_is_valid(ctx, sizeof(hash_ctx)))
        return 0;
    memset(&ctx->bash.s, 0, sizeof(ctx->bash.s));
    ctx->bash.s[184] = 2 * l / 8;
    ctx->bash.buf_len = (1536 - 4 * l) / 8;
    ctx->bash.pos = 0;
    ctx->bash.l = l;
    return 1;
}

unsigned char bash_hash_step(hash_ctx* ctx, const unsigned char* buf, size_t count)
{
    if (!mem_is_valid(ctx, sizeof(hash_ctx)) || !mem_is_valid_with_0(buf, count))
        return 0;
    // не накопился полный буфер?
    if (count < ctx->bash.buf_len - ctx->bash.pos)
    {
        memcpy(ctx->bash.s + ctx->bash.pos, buf, count);
        ctx->bash.pos += count;
        return 1;
    }
    // новый полный буфер
    memcpy(ctx->bash.s + ctx->bash.pos, buf, ctx->bash.buf_len - ctx->bash.pos);
    buf += ctx->bash.buf_len - ctx->bash.pos;
    count -= ctx->bash.buf_len - ctx->bash.pos;
    bash_f((unsigned long long*)(ctx->bash.s));
    // цикл по полным блокам
    while (count >= ctx->bash.buf_len)
    {
        memcpy(ctx->bash.s, buf, ctx->bash.buf_len);
        buf += ctx->bash.buf_len;
        count -= ctx->bash.buf_len;
        bash_f((unsigned long long*)(ctx->bash.s));
    }
    // неполный блок?
    if (ctx->bash.pos = count)
        memcpy(ctx->bash.s, buf, count);
    return 1;
}

unsigned char bash_hash_finish(hash_ctx* ctx, unsigned char* hash)
{
    if (!mem_is_valid(ctx, sizeof(hash_ctx)) || !mem_is_valid(hash, 2 * ctx->bash.l / 8))
        return 0;
    // есть необработанные данные?
    if (ctx->bash.pos)
    {
        memset(ctx->bash.s + ctx->bash.pos, 0x00, ctx->bash.buf_len - ctx->bash.pos);
        ctx->bash.s[ctx->bash.pos] = 0x40;
    }
    // дополнительный блок
    else
    {
        memset(ctx->bash.s, 0x00, ctx->bash.buf_len);
        ctx->bash.s[0] = 0x40;
    }
    bash_f((unsigned long long*)(ctx->bash.s));
    memcpy(hash, ctx->bash.s, 2 * ctx->bash.l / 8);
    memory_cleanse(ctx, sizeof(hash_ctx));
    return 1;
}

////////////////////////////////////////////////////////////////////////////////////////////////////

unsigned char bash_hash(const unsigned short l, const unsigned char* x, const size_t x_size, unsigned char* y)
{
    if (l == 0 || l % 16 != 0 || l > 256)
        return 0;
    if (!mem_is_valid_with_0(x, x_size) || !mem_is_valid(y, 2 * l / 8))
        return 0;
    hash_ctx ctx;
    bash_hash_start(&ctx, l);
    bash_hash_step(&ctx, x, x_size);
    bash_hash_finish(&ctx, y);
    return 1;
}

////////////////////////////////////////////////////////////////////////////////////////////////////

unsigned char bash256_hash_start(hash_ctx* ctx)
{
    return bash_hash_start(ctx, 128);
}

unsigned char bash384_hash_start(hash_ctx* ctx)
{
    return bash_hash_start(ctx, 192);
}

unsigned char bash512_hash_start(hash_ctx* ctx)
{
    return bash_hash_start(ctx, 256);
}

////////////////////////////////////////////////////////////////////////////////////////////////////

unsigned char bash256(const unsigned char* x, const size_t x_size, unsigned char* y)
{
    return bash_hash(128, x, x_size, y);
}

unsigned char bash384(const unsigned char* x, const size_t x_size, unsigned char* y)
{
    return bash_hash(192, x, x_size, y);
}

unsigned char bash512(const unsigned char* x, const size_t x_size, unsigned char* y)
{
    return bash_hash(256, x, x_size, y);
}

////////////////////////////////////////////////////////////////////////////////////////////////////

// СТБ 34.101.47-2017 (6.1)

void xor_byte_n(unsigned char* res, const unsigned char* arr, const unsigned char byte, const size_t n)
{
    size_t i;
    for (i = 0; i < n; i += 1)
        res[i] = arr[i] ^ byte;
}

const unsigned char IPAD = 0x36;
const unsigned char OPAD = 0x5C;

unsigned char hmac_start(hmac_ctx* ctx, const unsigned char* k, const size_t k_size)
{
    if (!mem_is_valid(ctx, sizeof(hmac_ctx)) || !mem_is_valid(k, k_size))
        return 0;
    static const hashFunc hF_bash_256 = { *bash256_hash_start, *bash_hash_step, *bash_hash_finish,*bash256, 1024, 128 };
    ctx->hF = hF_bash_256;
    memset(ctx->t, 0x00, sizeof(ctx->t));
    if (k_size <= hF_bash_256.b / 8)
        memcpy(ctx->t, k, k_size);
    else
        hF_bash_256.hash(k, k_size, ctx->t);
    xor_byte_n(ctx->t, ctx->t, IPAD, ctx->hF.b / 8);
    hF_bash_256.hash_start(&ctx->hctx);
    hF_bash_256.hash_step(&ctx->hctx, ctx->t, hF_bash_256.b / 8);
    return 1;
}

unsigned char hmac_step(hmac_ctx* ctx, const unsigned char* x, const size_t x_size)
{
    if (!mem_is_valid(ctx, sizeof(hmac_ctx)) || !mem_is_valid_with_0(x, x_size))
        return 0;
    ctx->hF.hash_step(&ctx->hctx, x, x_size);
    return 1;
}

unsigned char hmac_finish(hmac_ctx* ctx, unsigned char* y)
{
    if (!mem_is_valid(ctx, sizeof(hmac_ctx)) || !mem_is_valid(y, 2 * ctx->hF.l / 8))
        return 0;
    ctx->hF.hash_finish(&ctx->hctx, y);
    xor_byte_n(ctx->t, ctx->t, IPAD ^ OPAD, ctx->hF.b / 8);
    ctx->hF.hash_start(&ctx->hctx);
    ctx->hF.hash_step(&ctx->hctx, ctx->t, ctx->hF.b / 8);
    ctx->hF.hash_step(&ctx->hctx, y, 2 * ctx->hF.l / 8);
    ctx->hF.hash_finish(&ctx->hctx, y);
    memory_cleanse(ctx, sizeof(hmac_ctx));
    return 1;
}

unsigned char bash256_hmac(const unsigned char* k, const size_t k_size,
    const unsigned char* x, const size_t x_size, unsigned char* y)
{
    if (!mem_is_valid(k, k_size) || !mem_is_valid_with_0(x, x_size) || !mem_is_valid(y, 2 * 128 / 8))
        return 0;
    hmac_ctx ctx;
    hmac_start(&ctx, k, k_size);
    hmac_step(&ctx, x, x_size);
    hmac_finish(&ctx, y);
    return 1;
}

// --------------------------



#ifndef COMPAT_ZINC_IS_A_MODULE
int __init chacha20poly1305_mod_init(void)
#else
static int __init mod_init(void)
#endif
{
	return 0;
}

#ifdef COMPAT_ZINC_IS_A_MODULE
static void __exit mod_exit(void)
{
}



module_init(mod_init);
module_exit(mod_exit);
MODULE_LICENSE("GPL v2");
MODULE_DESCRIPTION("ChaCha20Poly1305 AEAD construction");
MODULE_AUTHOR("Jason A. Donenfeld <Jason@zx2c4.com>");
#endif
